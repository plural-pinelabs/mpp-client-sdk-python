from enum import Enum


class PaymentGateway(str, Enum):
    """Payment gateway used by seller challenges and buyer credentials."""

    PineLabsOnline = "PINE LABS ONLINE"


class PaymentMethod(str, Enum):
    """Payment methods supported by the current P3P service payload contract."""

    UpiSbmd = "SBMD"
    Crypto = "CRYPTO"


__all__ = ["PaymentGateway", "PaymentMethod"]
