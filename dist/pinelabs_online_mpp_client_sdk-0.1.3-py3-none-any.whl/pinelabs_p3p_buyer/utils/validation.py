from __future__ import annotations

import re

from ..config.environments import resolve_p3p_base_url
from ..types.config import PluralBuyerConfig
from ..types.payment import PaymentGateway, PaymentMethod
from ..types.token import CreateTokenOptions

_E164_RE = re.compile(r"^\+\d{10,15}$")
_LOCAL_MOBILE_RE = re.compile(r"^\d{10}$")


def normalize_mandate_mobile_number(value: str) -> str:
    digits = "".join(ch for ch in str(value or "") if ch.isdigit())
    if len(digits) > 10:
        return digits[-10:]
    return digits


def validate_config(config: PluralBuyerConfig) -> None:
    if config.paymentGateway != PaymentGateway.PineLabsOnline:
        raise ValueError("PluralBuyerConfig: paymentGateway must be PaymentGateway.PineLabsOnline")
    if not is_supported_payment_method(config.selectedPaymentMethod):
        raise ValueError("PluralBuyerConfig: selectedPaymentMethod must be a supported payment method")
    if config.env is not None:
        resolve_p3p_base_url(config.env)
    if config.requestTimeoutMs is not None and (not isinstance(config.requestTimeoutMs, int) or config.requestTimeoutMs <= 0):
        raise ValueError("PluralBuyerConfig: requestTimeoutMs must be a positive integer")
    if config.maxRetries is not None and (not isinstance(config.maxRetries, int) or config.maxRetries < 0):
        raise ValueError("PluralBuyerConfig: maxRetries must be a non-negative integer")
    if config.initialRetryDelayMs is not None and (not isinstance(config.initialRetryDelayMs, int) or config.initialRetryDelayMs <= 0):
        raise ValueError("PluralBuyerConfig: initialRetryDelayMs must be a positive integer")


def validate_create_token_options(options: CreateTokenOptions) -> None:
    if not (options.customerReference or options.customerId):
        raise ValueError("CreateTokenOptions: customerReference or customerId is required")
    if not str(options.mobileNumber or "").strip():
        raise ValueError("CreateTokenOptions: mobileNumber is required")
    if not str(options.challengeId or "").strip():
        raise ValueError("CreateTokenOptions: challengeId is required")
    payment_value = options.paymentAmount.value if options.paymentAmount is not None else (
        options.usageLimits.maxAmount if options.usageLimits is not None else None
    )
    payment_currency = options.paymentAmount.currency if options.paymentAmount is not None else (
        options.usageLimits.currency if options.usageLimits is not None else None
    )
    if not isinstance(payment_value, int) or payment_value <= 0:
        raise ValueError("CreateTokenOptions: paymentAmount.value must be a positive integer")
    if not payment_currency:
        raise ValueError("CreateTokenOptions: paymentAmount.currency is required")
    if options.paymentMethod is not None and not is_supported_payment_method(options.paymentMethod):
        raise ValueError("CreateTokenOptions: paymentMethod must be a supported payment method")


def is_supported_payment_method(value: object) -> bool:
    return value in (PaymentMethod.UpiSbmd, PaymentMethod.Crypto)
