from __future__ import annotations

import json

import httpx
import pytest

from pinelabs_p3p_buyer import (
    Amount,
    BuyerRuntimeContext,
    P3PChallengeError,
    P3PEnvironment,
    PaymentGateway,
    PaymentMethod,
    PluralBuyer,
    PluralBuyerConfig,
)
from pinelabs_p3p_buyer.client.credential_builder import encode_json, decode_json


class _BuyerTransport(httpx.BaseTransport):
    def __init__(self) -> None:
        self.requests: list[httpx.Request] = []

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        if request.url.path == "/api/premium":
            credential = request.headers.get("P3P-Credential", "")
            if not credential.startswith("Payment "):
                return httpx.Response(
                    402,
                    json={"status": 402, "challengeId": "ch_runtime"},
                    headers={
                        "WWW-Authenticate": "Payment "
                        + encode_json(
                            {
                                "id": "ch_runtime",
                                "realm": "Plural P3P",
                                "paymentGateway": "PINE LABS ONLINE",
                                "intent": "charge",
                                "request": {
                                    "scheme": "exact",
                                    "amount": "100.00",
                                    "currency": "INR",
                                    "resource": "/api/premium",
                                    "availablePaymentMethods": ["SBMD", "CRYPTO"],
                                },
                                "expires": "2030-01-01T00:00:00Z",
                            }
                        ),
                    },
                )
            return httpx.Response(200, json={"ok": True}, headers={"Payment-Receipt": ""})

        if request.url.path == "/api/v1/customer/mpp/token":
            return httpx.Response(
                200,
                json={
                    "data": {
                        "payment_token": "tok_runtime",
                        "expires_in": 300,
                        "type": "SBMD",
                        "payment_method_reference_id": "auth_runtime",
                    }
                },
            )

        return httpx.Response(404, json={"error": {"message": request.url.path}})


def _patch_httpx_client(monkeypatch: pytest.MonkeyPatch, transport: httpx.BaseTransport) -> None:
    real_client = httpx.Client

    def _client(*args, **kwargs):
        kwargs["transport"] = transport
        return real_client(*args, **kwargs)

    monkeypatch.setattr("httpx.Client", _client)


def test_buyer_uses_runtime_context_customer_token_endpoint_and_p3p_header(monkeypatch: pytest.MonkeyPatch) -> None:
    transport = _BuyerTransport()
    _patch_httpx_client(monkeypatch, transport)

    buyer = PluralBuyer.create(
        PluralBuyerConfig(
            paymentGateway=PaymentGateway.PineLabsOnline,
            selectedPaymentMethod=PaymentMethod.UpiSbmd,
            env=P3PEnvironment.SANDBOX,
        )
    )
    try:
        response = buyer.get(
            "https://seller.test/api/premium",
            context=BuyerRuntimeContext(
                customerKey="ck_test",
                customerReference="9876543210",
                mobileNumber="9876543210",
            ),
        )
    finally:
        buyer.close()

    assert response.status_code == 200
    token_request = next(req for req in transport.requests if req.url.path == "/api/v1/customer/mpp/token")
    token_body = json.loads(token_request.content.decode() or "{}")
    assert token_request.headers["X-Customer-Key"] == "ck_test"
    assert "Authorization" not in token_request.headers
    assert token_body == {
        "type": "SBMD",
        "customer": {"mobile_number": "9876543210"},
        "challenge_id": "ch_runtime",
        "payment_amount": {"value": 10000, "currency": "INR"},
    }

    paid_retry = next(
        req for req in reversed(transport.requests)
        if req.url.path == "/api/premium" and req.headers.get("P3P-Credential", "").startswith("Payment ")
    )
    assert "Authorization" not in paid_retry.headers
    credential = decode_json(paid_retry.headers["P3P-Credential"].removeprefix("Payment ").strip())
    assert credential["source"] == "9876543210"
    assert credential["payload"]["customer_reference"] == "9876543210"
    assert credential["payload"]["mobile_number"] == "9876543210"
    assert credential["payload"]["payment_method"] == "SBMD"


def test_buyer_requires_runtime_context_for_auto_payment(monkeypatch: pytest.MonkeyPatch) -> None:
    transport = _BuyerTransport()
    _patch_httpx_client(monkeypatch, transport)
    buyer = PluralBuyer.create(
        PluralBuyerConfig(
            paymentGateway=PaymentGateway.PineLabsOnline,
            selectedPaymentMethod=PaymentMethod.UpiSbmd,
            env=P3PEnvironment.SANDBOX,
        )
    )
    try:
        with pytest.raises(RuntimeError, match="BuyerRuntimeContext"):
            buyer.get("https://seller.test/api/premium")
    finally:
        buyer.close()


def test_buyer_surface_has_no_mpp_aliases() -> None:
    import pinelabs_p3p_buyer as buyer

    assert hasattr(buyer, "P3PEnvironment")
    assert not hasattr(buyer, "MppEnvironment")
    assert hasattr(buyer, "P3PError")
    assert not hasattr(buyer, "MppError")
    assert P3PChallengeError.__name__ == "P3PChallengeError"
