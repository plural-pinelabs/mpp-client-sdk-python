from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Protocol

from ..config.environments import P3PEnvironment
from .challenge import Challenge, Receipt
from .payment import PaymentGateway, PaymentMethod


class P3PLogger(Protocol):
    def debug(self, message: str, context: Optional[Dict[str, Any]] = None) -> None: ...
    def info(self, message: str, context: Optional[Dict[str, Any]] = None) -> None: ...
    def error(self, message: str, context: Optional[Dict[str, Any]] = None) -> None: ...


@dataclass
class TokenDefaults:
    """Optional defaults used when the buyer SDK creates payment tokens automatically."""

    maxCharges: Optional[int] = None
    ttlSeconds: Optional[int] = None


@dataclass
class PluralBuyerConfig:
    """Configuration required to construct a buyer SDK instance.

    Customer identity is supplied per request via `BuyerRuntimeContext` so one
    buyer instance can serve multiple customers safely.
    """

    paymentGateway: PaymentGateway
    selectedPaymentMethod: PaymentMethod
    env: Optional[str] = P3PEnvironment.PRODUCTION
    autoHandlePayment: bool = True
    onChallenge: Optional[Callable[[Challenge], Any]] = None
    onPaymentComplete: Optional[Callable[[Receipt], Any]] = None
    tokenDefaults: Optional[TokenDefaults] = None
    requestTimeoutMs: Optional[int] = None
    maxRetries: Optional[int] = None
    initialRetryDelayMs: Optional[int] = None
    logger: Optional[P3PLogger] = None


@dataclass
class BuyerRuntimeContext:
    """Per-request customer context for automatic 402 payment handling."""

    customerKey: Optional[str] = None
    customerReference: Optional[str] = None
    mobileNumber: Optional[str] = None


# NOTE: BuyerMethods / PluralBuyerInstance are structural interfaces — the
# Python SDK exposes these via the PluralBuyer class directly.
BuyerMethods = object
PluralBuyerInstance = object

__all__ = [
    "BuyerMethods",
    "BuyerRuntimeContext",
    "P3PLogger",
    "PluralBuyerConfig",
    "PluralBuyerInstance",
    "PaymentGateway",
    "PaymentMethod",
    "TokenDefaults",
]
